/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.loginandregister;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author packardbell
 */
public class Loginandregister {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
 import java.util.ArrayList; import java.util.Scanner;
  class LoginRegistration{
      Scanner sc = new Scanner(System.in);
     ArrayList<User> userData = new ArrayList<>();
      public LoginRegistration(){
         processMenu();
     }
      private void processMenu(){
         System.out.println("n1. Registern2. Loginn3. ExitnEnter your option: ");
         int choice = sc.nextInt();
         switch (choice){
             case 1:
                 register();
                 break;
             case 2:
                 login();
                 break;
             case 3:
         }
     }
      private void register(){
         sc.nextLine();
         System.out.println("Enter Unsername: ");
         String username = sc.nextLine();
         System.out.println("Enter Password: ");
         String password = sc.nextLine();
         System.out.println("Enter First Name: ");
         String firstName = sc.nextLine();
         System.out.println("Enter Last Name: ");
         String lastName = sc.nextLine();
         userData.add(new User(username, password, firstName, lastName));
         System.out.println("User registered!");
         processMenu();
     }
      private void login(){
         sc.nextLine();
         System.out.println("Enter Username: ");
         String username = sc.nextLine();
         boolean userNameExist = false;
         User user = null;
         for (User u : userData){
             if (u.getUsername().equals(username)) {
                 userNameExist = true;
                 user = u;
                 break;
             }
         }
         if (!userNameExist){
             System.out.println("Username does not exist!");
             processMenu();
         }
         System.out.println("Enter Password: ");
         String password = sc.nextLine();
         if (!user.getPassword().equals(password)){
             System.out.println("Invalid password!");
             processMenu();
         }
         else {
             System.out.println("Logged in!");
         }
         processMenu();
     }
       public static void main(String[] args){
         new LoginRegistration();
     } }
  class User{
     private String username;
     private String password;
     private String firstName;
     private String lastName;
      User(String username, String password, String firstName, String lastName) {
         this.username = username;
         this.password = password;
         this.firstName = firstName;
         this.lastName = lastName;
     }
      public String getUsername() {
         return username;
     }
      public void setUsername(String username) {
         this.username = username;
     }
      public String getPassword() {
         return password;
     }
      public void setPassword(String password) {
         this.password = password;
     }
      public String getFirstName() {
         return firstName;
     }
      public void setFirstName(String firstName) {
         this.firstName = firstName;
     }
      public String getLastName() {
         return lastName;
     }
      public void setLastName(String lastName) {
         this.lastName = lastName;
     } }